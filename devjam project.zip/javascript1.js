const express=require('express')
const morgan=require('morgan')
const mongoose=require('mongoose')
const Connect=require('./models/connect')
//express app
const app=express();
//connection to mongoDB
const dburi = 'mongodb+srv://Dhruv:devjam@geekcoders.w67n18c.mongodb.net/node123?retryWrites=true&w=majority';
mongoose.connect(dburi)
.then((result)=>console.log('connected to db'))
.catch((err)=>console.log(err))
//register view engines
app.set('view engine','ejs')
//listen function
app.listen(3000);
//static function(middleware)
app.use( express.static( "public") );
app.use(morgan('dev'))
app.use(express.urlencoded({extended:true}))
//mongoose and mongo sandbox routes
/*const connect=new Connect({
    Name:'Dhruv',
    Phone:98456646,
    Email:'bhjgi@gmail.com',
    Subject:'bjbghigbi',
})*/
//connect.save()
//post function
app.post('/connect',(req,res)=>{
    const connect=new Connect(req.body)
    connect.save()
     .then((result)=>{
       res.redirect('/')
    })
    .catch((err)=>{
        console.log(err)
    })
})
//get function
app.get('/',(req,res)=>{
    res.render('index1',{title:'Home'})
})
app.get('/happy',(req,res)=>{
    res.render('happy',{title:'Happy Mood'})
})
app.get('/sad',(req,res)=>{
    res.render('sad',{title:'Sad Mood'})
})
app.get('/romantic',(req,res)=>{
    res.render('romantic',{title:'Romantic Mood'})
})
app.get('/motivational',(req,res)=>{
    res.render('motivational',{title:'Motivational Mood'})
})
//use function
/*app.use((req,res)=>{
    res.render('404')
})*/